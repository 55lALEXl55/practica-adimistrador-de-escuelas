﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{

    public partial class windowSeleccion : Window
    {
        public Agregar_Clases agregarClases;
        public AgregarPersona agregarPersona;
        public AgregarNotas agregarNotas;
        public ReportesWindow reportesWindow;
        Persona usuario; 

        public windowSeleccion(string Rol)
        {

            this.usuario = usuario;
            agregarClases = new Agregar_Clases(this,Rol);
            InitializeComponent();
            agregarPersona = new AgregarPersona(this);
            agregarNotas = new AgregarNotas(this,Rol);
            reportesWindow = new ReportesWindow(this);
          
            if (Rol == "Estudiante") 
            {
             
                btnUsuarios.IsEnabled = false;
                btnClase.Content = "Ver Clases";
                btnNota.Content = "Ver Notas";

                btnUsuarios.Opacity = 0.8;
            }
            if (Rol == "Maestro")
            {

                btnUsuarios.IsEnabled = false;
                btnUsuarios.Opacity = 0.8;
            }


        }
		private void TBShow_Checked(object sender, RoutedEventArgs e)
		{
			GridContent.Opacity = 0.5;
		}

		private void TBHide_Unchecked(object sender, RoutedEventArgs e)
		{
			GridContent.Opacity = 1;
		}

		private void BottonDownBG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			btnShowHide.IsChecked = false;
		}

		private void btnCerrar_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		private void btnMinimizar_Click(object sender, RoutedEventArgs e)
		{
			this.WindowState = WindowState.Minimized;
		}

		private void btnUsuarios_Click(object sender, RoutedEventArgs e)
		{
			this.Hide();
			agregarPersona.Show();
		}

		private void btnClase_Click(object sender, RoutedEventArgs e)
		{
			this.Hide();
			agregarClases.Show();
		}

		private void btnNota_Click(object sender, RoutedEventArgs e)
		{
			this.Hide();
			agregarNotas.Show();
		}

		private void btnReporte_Click(object sender, RoutedEventArgs e)
		{
			this.Hide();
			reportesWindow.Show();
		}
	}
}
