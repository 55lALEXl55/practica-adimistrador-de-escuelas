﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Lógica de interacción para modificarNotas.xaml
    /// </summary>
    public partial class modificarNotas : Window
    {
        public Nota notas { get; set; }
        public modificarNotas()
        {

            InitializeComponent();
        }
        public modificarNotas(Nota nota)
        {
            InitializeComponent();
            notas = new Nota { nombreEstudiante = nota.nombreEstudiante, nota1 = nota.nota2, nota2 = nota.nota2, nota3 = nota.nota3 };
            DataContext = this;

        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {


            if (!string.IsNullOrWhiteSpace(txtNombre.Text) && !string.IsNullOrWhiteSpace(txtPrimer.Text) && !string.IsNullOrWhiteSpace(txtSegundo.Text) && !string.IsNullOrWhiteSpace(txtTercero.Text))
            {
                notas.nombreEstudiante = txtNombre.Text;
                notas.nota1 = txtPrimer.Text;
                notas.nota2 = txtSegundo.Text;
                notas.nota3 = txtTercero.Text;
                DialogResult = true;

                this.Close();




            }
            else
            {
                MessageBox.Show("Por favor, ingrese un nombre de producto válido y un precio numérico.");
            }
        }
    }
}

    
