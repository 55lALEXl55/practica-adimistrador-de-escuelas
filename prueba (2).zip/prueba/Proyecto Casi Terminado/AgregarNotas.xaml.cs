﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Lógica de interacción para AgregarNotas.xaml
    /// </summary>
    public partial class AgregarNotas : Window
    {


        private ObservableCollection<Nota> notas;
        private windowSeleccion windowseleccion;
        public AgregarNotas(windowSeleccion ws, string Rol)
        {
            InitializeComponent();
            notas = new ObservableCollection<Nota>();
            InitializeComponent();
            notasDataGrid.ItemsSource = notas;

            windowseleccion = ws;

            if (Rol == "Estudiante")
            {
                notasBoton.Visibility = Visibility.Collapsed;
               modificarNotasButton.Visibility = Visibility.Collapsed;
                eliminarNotasButton.Visibility = Visibility.Collapsed;
                registrarNotasButton.Visibility = Visibility.Collapsed;

                txtNombre.IsEnabled = false;
                txtPrimer.IsEnabled = false;
                txtSegundo.IsEnabled = false;
                txtTercero.IsEnabled = false;

            }

        }

        private void notasBoton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNombre.Text) && !string.IsNullOrEmpty(txtPrimer.Text) && !string.IsNullOrEmpty(txtSegundo.Text) && !string.IsNullOrEmpty(txtTercero.Text))
            {
                Nota nuevaNota = new Nota { nombreEstudiante = txtNombre.Text, nota1 = txtPrimer.Text, nota2 = txtSegundo.Text, nota3 = txtTercero.Text };
                notas.Add(nuevaNota);

                txtNombre.Clear();
                txtPrimer.Clear();
                txtSegundo.Clear();
                txtTercero.Clear();
            }
            else
            {
                MessageBox.Show("Por favor, ingrese valores válidos en todos los campos");
            }
        }

        private void modificarNotasButton_Click(object sender, RoutedEventArgs e)
        {
            // Modificar el producto seleccionado del DataGrid
            if (notasDataGrid.SelectedItem != null)
            {
                Nota notaSeleccionada = (Nota)notasDataGrid.SelectedItem;
                modificarNotas modificarProductoWindow = new modificarNotas(notaSeleccionada);
                if (modificarProductoWindow.ShowDialog() == true)
                {
                    // Actualizar el producto con los nuevos valores
                    notaSeleccionada.nombreEstudiante = modificarProductoWindow.notas.nombreEstudiante;
                    notaSeleccionada.nota1 = modificarProductoWindow.notas.nota1;
                    notaSeleccionada.nota2 = modificarProductoWindow.notas.nota2;
                    notaSeleccionada.nota3 = modificarProductoWindow.notas.nota3;
                }
            }

        }

        private void registrarNotasButton_Click(object sender, RoutedEventArgs e)
        {
            string filePath = "";

            if (comboNotas.SelectedIndex == 0)
            {
                filePath = "C:\\archivos\\notasBiologia.txt";
            }
            else if (comboNotas.SelectedIndex == 1)
            {
                filePath = "C:\\archivos\\notasMatematicas.txt";
            }
            else if (comboNotas.SelectedIndex == 2)
            {
                filePath = "C:\\archivos\\notasQuimica.txt";
            }
            else if (comboNotas.SelectedIndex == 3)
            {
                filePath = "C:\\archivos\\notasInformatica.txt";
            }
            else if (comboNotas.SelectedIndex == 4)
            {
                filePath = "C:\\archivos\\notasIngles.txt";
            }
            else if (comboNotas.SelectedIndex == 5)
            {
                filePath = "C:\\archivos\\notasFisica.txt";
            }

            FileStream fs = new FileStream(filePath, FileMode.Create);
            string cadena;
            foreach (Nota nota in notas)
            {
                cadena = nota.nombreEstudiante + "," + nota.nota1 + "," + nota.nota2 + "," + nota.nota2 + "," + "\n";
                byte[] bdata = Encoding.Default.GetBytes(cadena);
                fs.Write(bdata, 0, bdata.Length);
                cadena = "";
            }
            MessageBox.Show("Reporte de Personas grabado en el archivo.");
            fs.Close();

        }

        private void eliminarNotasButton_Click(object sender, RoutedEventArgs e)
        {
            if (notasDataGrid.SelectedItem != null)
            {
                Nota notaSeleccionada = (Nota)notasDataGrid.SelectedItem;
                notas.Remove(notaSeleccionada);
            }
        }
        public void leerDatos(string path)
        {
            string cadena;
            notas.Clear();

            using (StreamReader sr = new StreamReader(path))
            {
                while ((cadena = sr.ReadLine()) != null)
                {
                    string[] atributos = cadena.Split(',');

                    while (atributos.Length < 4)
                    {
                        atributos = atributos.Concat(new string[] { "" }).ToArray();
                    }

                    Nota nuevaNota = new Nota
                    {
                        nombreEstudiante = atributos[0],
                        nota1 = atributos[1],
                        nota2 = atributos[2],
                        nota3 = atributos[3],
                    };
                    notas.Add(nuevaNota);
                }
            }
        }





        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            windowseleccion.Show();
        }

        private void comboNotas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            notas.Clear();

            string filePath = "";

            switch (comboNotas.SelectedIndex)
            {
                case 0:
                    filePath = "C:\\archivos\\notasBiologia.txt";
                    break;
                case 1:
                    filePath = "C:\\archivos\\notasMatematicas.txt";
                    break;
                case 2:
                    filePath = "C:\\archivos\\notasQuimica.txt";
                    break;
                case 3:
                    filePath = "C:\\archivos\\notasInformatica.txt";
                    break;
                case 4:
                    filePath = "C:\\archivos\\notasIngles.txt";
                    break;
                case 5:
                    filePath = "C:\\archivos\\notasFisica.txt";
                    break;
            }

            if (!string.IsNullOrEmpty(filePath))
            {
                leerDatos(filePath);
            }
        }
    }
    }


