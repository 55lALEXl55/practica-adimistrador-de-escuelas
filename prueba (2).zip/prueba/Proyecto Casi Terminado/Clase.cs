﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    public class Clase
    {
        public string NombreDocente { get; set; }
        public string NombreClase { get; set; }
        public string Aula { get; set; }
        public string Hora { get; set; }

        public string Dia { get; set; }
        public Maestro Maestro
        {
            get => default;
            set
            {
            }
        }

        public Estudiante Estudiante
        {
            get => default;
            set
            {
            }
        }
    }

}