﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApp2
{

    public class Nota
    {
        public string nombreEstudiante { get; set; }
        public string nota1 { get; set; }
        public string nota2 { get; set; }
        public string nota3 { get; set; }
        public string notaFinal
        {
            get
            {
                int nota1Int, nota2Int, nota3Int;
                if (int.TryParse(nota1, out nota1Int) && int.TryParse(nota2, out nota2Int) && int.TryParse(nota3, out nota3Int))
                {
                    double promedio = (nota1Int + nota2Int + nota3Int) / 3.0;
                    return promedio.ToString("N2");
                }
                return "Error";
            }
        }
    }
}

