﻿using System.DirectoryServices.ActiveDirectory;
using System.Windows;

namespace WpfApp2
{
    public partial class MainWindow : Window
    {
        private Persona persona;
        private windowSeleccion windowseleccion;
        string Rol = "";
        public MainWindow()
        {
            InitializeComponent();
            persona = new Persona();
           
        }

        public Persona Persona
        {
            get { return persona; }
            set { persona = value; }
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;

         

            if (EsValidoUsuario(username, password) )
            {
               
                MessageBox.Show("Inicio de sesión exitoso.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                windowseleccion = new windowSeleccion(Rol);
                this.Close();

              
                windowseleccion.Show();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos. Inténtalo de nuevo.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
         private bool EsValidoUsuario(string username, string password)
        {
            string rutaArchivo = "C:\\archivos\\Usuarios.txt";
            string[] lineas = System.IO.File.ReadAllLines(rutaArchivo);

           


            foreach (string linea in lineas)
            {
                string[] partes = linea.Split(',');

                


                if (partes.Length == 6 && partes[4] == username && partes[5] == password)
                {
                    Rol = partes[3];
                    return true ;
              
                }



             


            }

            return false;

        }



        private void close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
