﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Lógica de interacción para AgregarPersona.xaml
    /// </summary>
    public partial class AgregarPersona : Window
    {
        private windowSeleccion windowseleccion;

        private ObservableCollection<Persona> personas;



        public AgregarPersona(windowSeleccion ws)
        {
            personas = new ObservableCollection<Persona>();
            InitializeComponent();
            DataGridPersonas.ItemsSource = personas;
            windowseleccion = ws;
            cb_grado.Opacity = 0.5;
            cb_grado.IsEnabled = false;
        }
      
        private void btnRegistrarCliente_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNombre.Text) && !string.IsNullOrEmpty(txtApellido.Text) && !string.IsNullOrEmpty(txtApellido2.Text) && !string.IsNullOrWhiteSpace(cb_rol.Text) && !string.IsNullOrEmpty(txtUsuario.Text) && !string.IsNullOrEmpty(txtContrasenia.Text) && !string.IsNullOrWhiteSpace(cb_grado.Text))
            {
                Persona nuevaPersona = new Persona
                {
                    nombre = txtNombre.Text,
                    primerApellido = txtApellido.Text,
                    segundoApellido = txtApellido2.Text,
                   


                };


                nuevaPersona.AgregarUsuarioContrasenia(txtUsuario.Text, txtContrasenia.Text, cb_rol.Text);


                personas.Add(nuevaPersona);

                txtNombre.Clear();
                txtApellido.Clear();
                txtApellido2.Clear();
                cb_rol.SelectedItem = null;
                txtUsuario.Clear();
                txtContrasenia.Clear();
                cb_grado.SelectedItem = null;
            }
            else
            {
                MessageBox.Show("Por favor, ingrese valores válidos en todos los campos");
            }
        }






        private void modificarButton_Click(object sender, RoutedEventArgs e)
        {
            
            if (DataGridPersonas.SelectedItem != null)
            {
                Persona personaSeleccionada = (Persona)DataGridPersonas.SelectedItem;
    
                ModificarPersona modificarPersonaWindow = new ModificarPersona(personaSeleccionada);
                if (modificarPersonaWindow.ShowDialog() == true)
                {
                    
                    personaSeleccionada.nombre = modificarPersonaWindow.personas.nombre;
                    personaSeleccionada.primerApellido = modificarPersonaWindow.personas.primerApellido;
                    personaSeleccionada.segundoApellido = modificarPersonaWindow.personas.segundoApellido;
                  
                   
                }
            }
        }


        private void eliminarButton_Click(object sender, RoutedEventArgs e)
        {
            if (DataGridPersonas.SelectedItem != null)
            {
                Persona personaSeleccionada = (Persona)DataGridPersonas.SelectedItem;
                personas.Remove(personaSeleccionada);
            }
        }

        private void grabarButton_Click(object sender, RoutedEventArgs e)
        {
            string rutaArchivo = "C:\\Archivos\\Usuarios.txt";

            using (System.IO.StreamWriter file = new System.IO.StreamWriter(rutaArchivo, false))
            {
                foreach (Persona persona in personas)
                {
                    string nombre = persona.nombre;
                    string primerApellido = persona.primerApellido;
                    string segundoApellido = persona.segundoApellido;
                  

                    
                        string usuario = persona.usuarios[0];
                        string contrasenia = persona.contrasenias[0];
                        string rol = persona.rol[0];
                        string grado = persona.grado;

                        file.WriteLine($"{nombre},{primerApellido},{segundoApellido},{rol},{usuario},{contrasenia},{grado}");
                        persona.AgregarUsuarioContrasenia(usuario, contrasenia, rol);
                    
                }
            }

            MessageBox.Show("Reporte de Personas grabado en el archivo.");
        }
      

        private void cb_rol_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cb_rol.SelectedIndex == 2)
            {
                cb_grado.IsEnabled = true;
                cb_grado.Opacity = 1;
            }
            else
            {
                cb_grado.IsEnabled = false;
				cb_grado.Opacity = 0.5;
			}
        }

        private void leerButton_Click(object sender, RoutedEventArgs e)
        {
            string cadena;
            personas.Clear();

            using (StreamReader sr = new StreamReader("C:\\Archivos\\Usuarios.txt"))
            {
                while ((cadena = sr.ReadLine()) != null)
                {
                    string[] atributos = cadena.Split(',');

                    // Completar los elementos faltantes con espacios en blanco

                    while (atributos.Length < 7)
                    {
                        atributos = atributos.Concat(new string[] { "" }).ToArray();
                    }

                    Persona nuevaPersona = new Persona
                    {
                        nombre = atributos[0],
                        primerApellido = atributos[1],
                        segundoApellido = atributos[2],
                        grado = atributos[6],
                        
                    };

                    nuevaPersona.AgregarUsuarioContrasenia(atributos[4], atributos[5], atributos[3]);

                    personas.Add(nuevaPersona);
                }
            }
        }

        private void buttonVolver_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            windowseleccion.Show();
        }
    }
}