﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{

    public partial class Window2 : Window
    {
        public Clase clases { get; set; }

        public Window2(Clase clase)
        {
            InitializeComponent();
            clases = new Clase { NombreClase = clase.NombreClase, NombreDocente = clase.NombreDocente, Aula = clase.Aula, Hora = clase.Hora, Dia = clase.Dia };
            DataContext = this;

        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {


            if (!string.IsNullOrWhiteSpace(ldocente.Text) && !string.IsNullOrWhiteSpace(lhora.Text) && !string.IsNullOrWhiteSpace(laula.Text) && !string.IsNullOrWhiteSpace(lClases.Text) && !string.IsNullOrWhiteSpace(ldia.Text))
            {
                clases.Dia= ldia.Text;
                clases.NombreDocente = ldocente.Text;
                clases.NombreClase = lClases.Text;
                clases.Hora = lhora.Text;
                clases.Aula = laula.Text;

                DialogResult = true;

                this.Close();




            }
            else
            {
                MessageBox.Show("Por favor, ingrese un nombre de producto válido y un precio numérico.");
            }
            }
        }
    }

