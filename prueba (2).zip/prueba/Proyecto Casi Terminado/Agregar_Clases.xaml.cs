﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{

    public partial class Agregar_Clases : Window
    {
        private Persona persona = new Persona();
        private windowSeleccion windowseleccion;
        private ObservableCollection<Clase> clases;
        public Agregar_Clases(windowSeleccion ws, string Rol)
        {
            clases = new ObservableCollection<Clase>();
            InitializeComponent();
            clasesDataGrid.ItemsSource = clases;
         
            windowseleccion = ws;


            if (Rol == "Estudiante")
            {
                b1.Visibility = Visibility.Collapsed;
                botonModificar.Visibility = Visibility.Collapsed;
                botonEliminar.Visibility = Visibility.Collapsed;
                btnGrabarReporteClientes.Visibility = Visibility.Collapsed;

                ldia.IsEnabled = false;
                lClases.IsEnabled = false;
                laula.IsEnabled = false;
                ldocente.IsEnabled = false;
                lhora.IsEnabled = false;



            }
        }

        private void AgregarClase_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(ldocente.Text) && !string.IsNullOrEmpty(lhora.Text) && !string.IsNullOrEmpty(laula.Text) && !string.IsNullOrEmpty(lClases.Text) && !string.IsNullOrEmpty(ldia.Text))
            {
                Clase nuevaClase = new Clase { NombreDocente = ldocente.Text, NombreClase = lClases.Text, Aula = laula.Text, Hora = lhora.Text ,  Dia = ldia.Text };
                clases.Add(nuevaClase);

                ldocente.Clear();
                lClases.Clear();
                lhora.Clear();
                laula.Clear();
                ldia.Clear();

            }

            
        }
        private void btnGrabarReporteClientes_Click(object sender, RoutedEventArgs e)
        {
            string filePath = "";

            if (combo_Clases.SelectedIndex == 0)
            {
                filePath = "C:\\archivos\\Clases.txt";
            }
            else if (combo_Clases.SelectedIndex == 1)
            {
                filePath = "C:\\archivos\\Clases5to.txt";
            }
            else if (combo_Clases.SelectedIndex == 2)
            {
                filePath = "C:\\archivos\\Clases4to.txt";
            }
            else if (combo_Clases.SelectedIndex == 3)
            {
                filePath = "C:\\archivos\\Clases3ro.txt";
            }
            else if (combo_Clases.SelectedIndex == 4)
            {
                filePath = "C:\\archivos\\Clases2do.txt";
            }
            else if (combo_Clases.SelectedIndex == 5)
            {
                filePath = "C:\\archivos\\Clases1ro.txt";
            }
         

            if (string.IsNullOrEmpty(filePath))
            {
                MessageBox.Show("Por favor, selecciona una opción válida en combo_Clases.");
                return;
            }

            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                string cadena;
                foreach (Clase clase in clases)
                {
                    cadena = clase.Dia + "," + clase.NombreClase + "," + clase.NombreDocente + "," + clase.Hora + "," + clase.Aula + "\n";
                    byte[] bdata = Encoding.Default.GetBytes(cadena);
                    fs.Write(bdata, 0, bdata.Length);
                    cadena = "";
                }
            }
            MessageBox.Show("Reporte de Personas grabado en el archivo.");
        }

        private void ModifyProduct_Click(object sender, RoutedEventArgs e)
        {
            // Modificar el producto seleccionado del DataGrid
            if (clasesDataGrid.SelectedItem != null)
            {
                Clase claseSeleccionada = (Clase)clasesDataGrid.SelectedItem;
                Window2 modificarProductoWindow = new Window2(claseSeleccionada);
                if (modificarProductoWindow.ShowDialog() == true)
                {
                    // Actualizar el producto con los nuevos valores
                    claseSeleccionada.Dia = modificarProductoWindow.clases.Dia;
                    claseSeleccionada.NombreClase = modificarProductoWindow.clases.NombreClase;
                    claseSeleccionada.NombreDocente = modificarProductoWindow.clases.NombreDocente;
                    claseSeleccionada.Hora = modificarProductoWindow.clases.Hora;
                    claseSeleccionada.Aula = modificarProductoWindow.clases.Aula;
                 

                }
            }
        }

        public void leerDatos(string path)
        {
            string cadena;
            clases.Clear();

            using (StreamReader sr = new StreamReader(path))
            {
                while ((cadena = sr.ReadLine()) != null)
                {
                    string[] atributos = cadena.Split(',');

                    while (atributos.Length < 5) 
                    {
                        atributos = atributos.Concat(new string[] { "" }).ToArray();
                    }

                    Clase nuevaClase = new Clase
                    {
                        Dia = atributos[0],     
                        NombreClase = atributos[1],
                        NombreDocente = atributos[2],
                        Hora = atributos[3],
                        Aula = atributos[4],
                    };
                    clases.Add(nuevaClase);
                }
            }
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {

            if (clasesDataGrid.SelectedItem != null)
            {
                Clase productoSeleccionado = (Clase)clasesDataGrid.SelectedItem;
                clases.Remove(productoSeleccionado);
            }
        }

        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            windowseleccion.Show();
        }

        private void combo_Clases_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            clases.Clear();

            string filePath = "";

            switch (combo_Clases.SelectedIndex)
            {
                case 0:
                    filePath = "C:\\archivos\\Clases.txt";
                    break;
                case 1:
                    filePath = "C:\\archivos\\Clases5to.txt";
                    break;
                case 2:
                    filePath = "C:\\archivos\\Clases4to.txt";
                    break;
                case 3:
                    filePath = "C:\\archivos\\Clases3ro.txt";
                    break;
                case 4:
                    filePath = "C:\\archivos\\Clases2do.txt";
                    break;
                case 5:
                    filePath = "C:\\archivos\\Clases1ro.txt";
                    break;
            }

            if (!string.IsNullOrEmpty(filePath))
            {
                leerDatos(filePath);
            }
        }


            
    }
}
        