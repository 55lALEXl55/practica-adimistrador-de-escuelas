﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
 
    public partial class ModificarPersona : Window
    {
        public Persona personas { get; set; }
        public ModificarPersona(Persona persona)
        {
            InitializeComponent();
            personas = new Persona { nombre = persona.nombre, primerApellido = persona.primerApellido, segundoApellido = persona.segundoApellido 
            
            };

            DataContext = this;
        }

        private void btnRegistrarCliente_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNombre.Text) && !string.IsNullOrWhiteSpace(txtApellido.Text) && !string.IsNullOrWhiteSpace(txtApellido2.Text) && !string.IsNullOrWhiteSpace(cb_rol.Text) && !string.IsNullOrWhiteSpace(txtUsuario.Text) && !string.IsNullOrWhiteSpace(txtContrasenia.Text))
            {
                personas.nombre = txtNombre.Text;
                personas.primerApellido = txtApellido.Text;
                personas.segundoApellido = txtApellido2.Text;
                personas.rol.Add(cb_rol.Text);




                DialogResult = true;

                this.Close();




            }
            else
            {
                MessageBox.Show("Por favor, ingrese un nombre de producto válido y un precio numérico.");
            }
        }

        private void cb_rol_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
    }

