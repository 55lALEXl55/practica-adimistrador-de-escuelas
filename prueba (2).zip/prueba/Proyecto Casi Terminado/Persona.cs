﻿using System.Collections.Generic;
using System;

namespace WpfApp2
{
    public class Persona
    {
    
        public string nombre { get; set; }

        public string primerApellido { get; set; }
        public string segundoApellido { get; set; }
        public string grado {  get; set; }

        public List<string> rol { get; set; } = new List<string>();
        public List<string> usuarios { get; } = new List<string>();

        public List<string> contrasenias { get; } = new List<string>();
        public Persona()
        {
            usuarios = new List<string>();
            contrasenias = new List<string>();
        }
        public void AgregarUsuarioContrasenia(string nuevoUsuario, string nuevaContrasenia, string nuevorol)
        {
            usuarios.Add(nuevoUsuario);
            contrasenias.Add(nuevaContrasenia);
            rol.Add(nuevorol);
        }

        public bool EsValidoUsuario(string username, string password)
        {
            int index = usuarios.IndexOf(username);
            return index != -1 && index < contrasenias.Count && contrasenias[index] == password ;
        }
    }
}